import React, { useState } from 'react'
import { apiIngest } from '../hooks/useApi'

export default function Uploader() {
  const [file, setFile] = useState<File | null>(null)
  const [msg, setMsg] = useState<string>('')
  const [busy, setBusy] = useState(false)

  const onUpload = async () => {
    if (!file) return
    setMsg('Uploading & indexing...')
    setBusy(true)
    try {
      const res = await apiIngest(file)
      setMsg(`Indexed ✓  pages=${res.info.pages}, chunks=${res.info.chunks}`)
    } catch (e: any) {
      setMsg(e.message || 'Upload failed')
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="flex flex-col gap-3">
      <div className="flex items-center gap-3">
        <input
          className="file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-medium file:bg-brand-50 file:text-brand-700 hover:file:bg-brand-100"
          type="file"
          accept="application/pdf"
          onChange={(e) => setFile(e.target.files?.[0] ?? null)}
        />
        <button onClick={onUpload} disabled={!file || busy} className="btn-primary disabled:opacity-50">
          {busy ? 'Indexing…' : 'Ingest PDF'}
        </button>
      </div>
      <div className="text-sm text-gray-600 min-h-[1.25rem]">{msg}</div>
    </div>
  )
}
