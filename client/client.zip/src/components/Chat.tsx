import React, { useState } from 'react'
import { apiQuery } from '../hooks/useApi'

type Msg = { role: 'user' | 'bot', text: string }

export default function Chat() {
  const [q, setQ] = useState('')
  const [msgs, setMsgs] = useState<Msg[]>([])
  const [loading, setLoading] = useState(false)

  const ask = async () => {
    if (!q) return
    const userMsg: Msg = { role: 'user', text: q }
    setMsgs((m) => [...m, userMsg])
    setLoading(true)
    try {
      const res = await apiQuery(q, 5)
      const botMsg: Msg = { role: 'bot', text: res.answer }
      setMsgs((m) => [...m, botMsg])
    } catch (e: any) {
      setMsgs((m) => [...m, { role: 'bot', text: e.message || 'Something went wrong' }])
    } finally {
      setQ('')
      setLoading(false)
    }
  }

  return (
    <div className="grid gap-4">
      <div className="flex gap-2">
        <input
          className="input"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Ask something that's in your PDFs..."
          onKeyDown={(e) => e.key === 'Enter' ? ask() : null}
        />
        <button onClick={ask} disabled={!q || loading} className="btn-primary whitespace-nowrap disabled:opacity-50">
          {loading ? '...' : 'Ask'}
        </button>
      </div>

      <div className="grid gap-3">
        {msgs.map((m, i) => (
          <div
            key={i}
            className={`rounded-lg px-3 py-2 text-sm whitespace-pre-wrap ${
              m.role === 'bot'
                ? 'bg-gray-50 border border-gray-200'
                : 'bg-brand-50 text-brand-900 border border-brand-100'
            }`}
          >
            <div className="font-semibold text-xs mb-1 opacity-70">{m.role === 'bot' ? 'Assistant' : 'You'}</div>
            {m.text}
          </div>
        ))}
      </div>
    </div>
  )
}
