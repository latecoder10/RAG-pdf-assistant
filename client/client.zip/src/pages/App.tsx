import React from 'react'
import Uploader from '../components/Uploader'
import Chat from '../components/Chat'

export default function App() {
  return (
    <div className="max-w-4xl mx-auto p-6 md:p-10">
      <header className="mb-8">
        <h1 className="text-3xl md:text-4xl font-bold tracking-tight">Express + React RAG</h1>
        <p className="text-gray-600 mt-2">Upload a PDF, then ask questions based on its content.</p>
      </header>

      <section className="card p-5 md:p-6 mb-6">
        <h2 className="text-lg font-semibold mb-3">1) Index your document</h2>
        <Uploader />
      </section>

      <section className="card p-5 md:p-6">
        <h2 className="text-lg font-semibold mb-3">2) Ask your document</h2>
        <Chat />
      </section>

      <footer className="text-xs text-gray-500 mt-8">
        Built with Tailwind, Vite, Express, LangChain, Gemini, and Pinecone.
      </footer>
    </div>
  )
}
